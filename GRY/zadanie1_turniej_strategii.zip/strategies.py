def always_cooperate(history_self, history_opponent):
    return "C"

def always_defect(history_self, history_opponent):
    return "D"

def tit_for_tat(history_self, history_opponent):
    if not history_opponent:
        return "C"
    return history_opponent[-1]
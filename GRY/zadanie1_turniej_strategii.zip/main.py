from strategies import always_cooperate, always_defect, tit_for_tat
from tournament import play_tournament

if __name__ == "__main__":
    strategies = {
        "Always Cooperate": always_cooperate,
        "Always Defect": always_defect,
        "Tit For Tat": tit_for_tat,
    }

    scores = play_tournament(strategies, rounds=10)
    print("\nWyniki turnieju:")
    for strat, score in scores.items():
        print(f"{strat}: {score}")
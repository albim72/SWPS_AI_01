import numpy as np

class Agent:
    def __init__(self, position, goal):
        self.position = np.array(position, dtype=np.float32)
        self.velocity = np.random.uniform(-1, 1, size=2)
        self.goal = np.array(goal, dtype=np.float32)
        self.brain = np.random.uniform(-1, 1, (4, 2))  # 2D inputs, 2D outputs

    def sense(self, agents):
        avg_pos = np.mean([a.position for a in agents if a != self], axis=0)
        return np.concatenate([(self.goal - self.position), (avg_pos - self.position)])

    def update(self, agents):
        inputs = self.sense(agents)
        action = np.tanh(inputs @ self.brain)
        self.velocity += 0.1 * action
        self.position += self.velocity

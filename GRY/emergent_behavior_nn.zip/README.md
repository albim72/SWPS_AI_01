# Emergent Behavior in Neural Networks

This project demonstrates emergent behavior using a simple neural network-based agent system. Agents learn to navigate towards a goal while avoiding collisions, and interesting group dynamics (like flocking or chasing) can emerge.

## Project Structure

- `main.py`: Runs the simulation
- `agent.py`: Defines the neural network agent
- `environment.py`: Environment for agents
- `utils.py`: Helper functions
- `requirements.txt`: Dependencies

## Run

```
pip install -r requirements.txt
python main.py
```

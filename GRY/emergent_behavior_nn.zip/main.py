from agent import Agent
from environment import Environment
import matplotlib.pyplot as plt

NUM_AGENTS = 20
NUM_STEPS = 100

env = Environment(num_agents=NUM_AGENTS)

for step in range(NUM_STEPS):
    env.update()
    if step % 10 == 0:
        env.plot(title=f"Step {step}")

from agent import Agent
import numpy as np
import matplotlib.pyplot as plt

class Environment:
    def __init__(self, num_agents=10):
        self.agents = [Agent(position=np.random.rand(2)*10, goal=np.array([5,5])) for _ in range(num_agents)]

    def update(self):
        for agent in self.agents:
            agent.update(self.agents)

    def plot(self, title="Environment"):
        plt.figure(figsize=(6,6))
        for agent in self.agents:
            plt.plot(agent.position[0], agent.position[1], 'bo')
        plt.plot(5, 5, 'r*', markersize=15)
        plt.xlim(0, 10)
        plt.ylim(0, 10)
        plt.title(title)
        plt.grid(True)
        plt.show()

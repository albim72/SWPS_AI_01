# 3D Emergent Behavior Simulation

This interactive 3D simulation demonstrates emergent behavior using agents in a 3D environment. Each agent is controlled by a simple neural-like mechanism that responds to nearby agents and a common goal. The system showcases emergent phenomena such as clustering, avoidance, and coordinated movement.

## Requirements

```
pip install vpython numpy
```

## Run

```
python main.py
```

## Controls

- The simulation runs in a browser window or local 3D rendering window via VPython.
- Close the window to stop the simulation.

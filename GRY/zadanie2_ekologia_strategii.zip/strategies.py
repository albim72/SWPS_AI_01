import random

def always_cooperate(_, __):
    return "C"

def always_defect(_, __):
    return "D"

def tit_for_tat(_, history_opponent):
    if not history_opponent:
        return "C"
    return history_opponent[-1]

def random_strategy(_, __):
    return random.choice(["C", "D"])

strategy_pool = {
    "Coop": always_cooperate,
    "Defect": always_defect,
    "TFT": tit_for_tat,
    "Rand": random_strategy,
}
import random
from tournament import play_round

class Individual:
    def __init__(self, name, strategy_func):
        self.name = name
        self.strategy_func = strategy_func
        self.fitness = 0

    def play(self, opponent, rounds=5):
        score_self, score_opponent = play_round(self.strategy_func, opponent.strategy_func, rounds)
        self.fitness += score_self
        opponent.fitness += score_opponent

def initialize_population(strategy_pool, pop_size):
    strategies = list(strategy_pool.items())
    population = []

    for _ in range(pop_size):
        name, func = random.choice(strategies)
        population.append(Individual(name, func))

    return population

def evolve_population(population, rounds=5):
    # Reset fitness
    for ind in population:
        ind.fitness = 0

    # Losowe gry
    for i in range(len(population)):
        for j in range(i + 1, len(population)):
            population[i].play(population[j], rounds)

    # Sortowanie wg fitness
    population.sort(key=lambda x: x.fitness, reverse=True)

    print("Top 5:")
    for ind in population[:5]:
        print(f"{ind.name} | Fitness: {ind.fitness}")

    # Selekcja: najlepsza połowa się rozmnaża
    survivors = population[:len(population)//2]
    new_population = []

    while len(new_population) < len(population):
        parent = random.choice(survivors)
        clone = Individual(parent.name, parent.strategy_func)
        new_population.append(clone)

    return new_population
import random

from strategies import strategy_pool
from tournament import play_round
from nn_strategy import NeuralStrategy

class Individual:
    def __init__(self, name, strategy_func, is_nn=False):
        self.name = name
        self.strategy_func = strategy_func
        self.fitness = 0
        self.is_nn = is_nn

    def play(self, opponent, rounds=5):
        score_self, score_opponent = play_round(self.strategy_func, opponent.strategy_func, rounds)
        self.fitness += score_self
        opponent.fitness += score_opponent

def initialize_population(strategy_pool, pop_size):
    strategies = list(strategy_pool.items())
    population = []

    for _ in range(pop_size - 1):
        name, func = random.choice(strategies)
        population.append(Individual(name, func))

    # Dodanie jednego agenta z siecią neuronową
    population.append(Individual("Neural", NeuralStrategy(), is_nn=True))

    return population

def mutate_strategy(name, func):
    # if name == "Defect" and random.random() < 0.3:
    #     return "Coop", func
    # elif name == "Coop" and random.random() < 0.3:
    #     return "Defect", func
    # return name, func
    if random.random() < 0.2:
        new_name, new_func = random.choice(list(strategy_pool.items()))
        return new_name, new_func
    return name, func

def evolve_population(population, rounds=5):
    for ind in population:
        ind.fitness = 0

    for i in range(len(population)):
        for j in range(i + 1, len(population)):
            population[i].play(population[j], rounds)

    population.sort(key=lambda x: x.fitness, reverse=True)

    print("Top 5:")
    for ind in population[:5]:
        print(f"{ind.name} | Fitness: {ind.fitness}")

    survivors = population[:len(population)//2]
    new_population = []

    while len(new_population) < len(population):
        parent = random.choice(survivors)
        if parent.is_nn:
            child = Individual("Neural",NeuralStrategy(), is_nn=True)
            child.strategy_func.model.set_weights(parent.strategy_func.model.get_weights())
            new_population.append(child)
        else:
            mutated_name, mutated_func = mutate_strategy(parent.name, parent.strategy_func)
            new_population.append(Individual(mutated_name, mutated_func))

    return new_population
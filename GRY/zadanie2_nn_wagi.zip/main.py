from population import initialize_population, evolve_population
from strategies import strategy_pool
import csv

GENERATIONS = 10
POP_SIZE = 20
ROUNDS = 20

if __name__ == "__main__":
    population = initialize_population(strategy_pool, POP_SIZE)

    for generation in range(GENERATIONS):
        print(f"\nGeneracja {generation + 1}")
        population = evolve_population(population, ROUNDS)

    with open("fitness_history.csv", "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([generation + 1] + [agent.fitness for agent in population])
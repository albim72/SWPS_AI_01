import random


def ms1(history_self, history_opponent):
    if not history_opponent:
        return "C"
    if history_opponent[-1] == "D":
        return "D"
    return "C"

def ms2(history_self, history_opponent):
    return random.choice(["C", "D"])

def ms3(history_self, history_opponent):
    if len(history_self) % 3 == 2:
        return "D"
    return "C"

def ms4(history_self, history_opponent):
    """
    Strategia 'adaptive_shadow':
    - zaczyna od współpracy
    - jeśli przeciwnik zdradza, przechodzi w tryb odwetu
    - jeśli przeciwnik przez 3 rundy z rzędu współpracuje, wybacza i wraca do współpracy
    """

    if not history_opponent:
        return "C"  # start od współpracy

    # jeśli ostatni ruch przeciwnika to zdrada – kara
    if history_opponent[-1] == "D":
        return "D"

    # jeśli ostatnie 3 ruchy przeciwnika to 'C' – wybaczamy
    if len(history_opponent) >= 3 and history_opponent[-3:] == ["C", "C", "C"]:
        return "C"

    # jeśli wcześniejsze zdrady, ale ostatnio było spokojnie – obserwuj dalej
    if "D" in history_opponent[-3:]:
        return "D"

    return "C"  # domyślnie współpracuj
from strategies import always_cooperate, always_defect, tit_for_tat
from tournament import play_tournament
from mystrategy import ms1, ms2, ms3,ms4

if __name__ == "__main__":
    strategies = {
        "Always Cooperate": always_cooperate,
        "Always Defect": always_defect,
        "Tit For Tat": tit_for_tat,
        "ms1": ms1,
        "ms2": ms2,
        "ms3": ms3,
        "ms4": ms4
    }

    scores = play_tournament(strategies, rounds=80)
    print("\nWyniki turnieju:")
    for strat, score in scores.items():
        print(f"{strat}: {score}")
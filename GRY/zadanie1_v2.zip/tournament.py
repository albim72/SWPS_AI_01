def play_round(strategy1, strategy2, rounds=15):
    history1, history2 = [], []
    score1, score2 = 0, 0

    for _ in range(rounds):
        move1 = strategy1(history1, history2)
        move2 = strategy2(history2, history1)

        history1.append(move1)
        history2.append(move2)

        s1, s2 = score(move1, move2)
        score1 += s1
        score2 += s2

    return score1, score2

def score(move1, move2):
    if move1 == "C" and move2 == "C":
        return 3, 3
    elif move1 == "D" and move2 == "D":
        return 1, 1
    elif move1 == "C" and move2 == "D":
        return 0, 5
    elif move1 == "D" and move2 == "C":
        return 5, 0

def play_tournament(strategies, rounds=15):
    results = {name: 0 for name in strategies}
    names = list(strategies.keys())

    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            s1 = strategies[names[i]]
            s2 = strategies[names[j]]

            score1, score2 = play_round(s1, s2, rounds)
            results[names[i]] += score1
            results[names[j]] += score2

    return results
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam

class NeuralStrategy:
    def __init__(self):
        self.model = self._build_model()

    def _build_model(self):
        model = Sequential()
        model.add(Dense(16, input_shape=(10,), activation='relu'))
        model.add(Dense(1, activation='sigmoid'))
        model.compile(optimizer=Adam(learning_rate=0.01), loss='binary_crossentropy')
        return model

    def __call__(self, history_self, history_opponent):
        history = (history_opponent + ['C'] * 5)[:5]
        binary = [1 if h == 'D' else 0 for h in history]
        input_vec = np.array(binary + [0] * (10 - len(binary)))[np.newaxis, :]
        prediction = self.model.predict(input_vec, verbose=0)[0][0]
        return 'D' if prediction > 0.5 else 'C'
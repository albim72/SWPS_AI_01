import numpy as np

class Agent:
    def __init__(self, init_value):
        self.value = init_value
        self.brain = np.random.uniform(-1, 1, (3,))  # 3 weights

    def update(self, others_values):
        mean = np.mean(others_values)
        diff = mean - self.value
        inputs = np.array([self.value, mean, diff])
        change = np.tanh(np.dot(inputs, self.brain))
        self.value += 0.1 * change

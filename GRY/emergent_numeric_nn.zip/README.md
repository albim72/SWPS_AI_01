# Emergent Behavior Based on Numeric Neural Networks

This project simulates emergent behavior using agents controlled by neural networks operating over numeric (scalar) inputs. Each agent receives numerical data about the environment and other agents, and decides on a new position or behavior using a simple feed-forward neural net.

## Requirements

```
pip install numpy matplotlib
```

## Run

```
python main.py
```


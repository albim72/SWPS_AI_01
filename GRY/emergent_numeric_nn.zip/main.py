import numpy as np
import matplotlib.pyplot as plt

from agent import Agent

NUM_AGENTS = 30
STEPS = 100

agents = [Agent(np.random.rand()) for _ in range(NUM_AGENTS)]

history = []

for step in range(STEPS):
    all_values = np.array([a.value for a in agents])
    avg = np.mean(all_values)

    for agent in agents:
        agent.update(all_values)

    history.append(all_values.copy())

# Plotting
history = np.array(history)
plt.figure(figsize=(12, 6))
for i in range(NUM_AGENTS):
    plt.plot(history[:, i], label=f"Agent {i}", alpha=0.6)
plt.axhline(y=avg, color='r', linestyle='--', label='Final Avg')
plt.title("Emergent Behavior of Numeric NN Agents")
plt.xlabel("Steps")
plt.ylabel("Value")
plt.grid(True)
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize='small')
plt.tight_layout()
plt.show()

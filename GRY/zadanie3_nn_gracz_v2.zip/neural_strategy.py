from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
import numpy as np

class NeuralStrategy:
    def __init__(self):
        self.model = self.build_model()

    def build_model(self):
        model = Sequential()
        model.add(Dense(8, input_dim=4, activation='relu'))
        model.add(Dense(1, activation='sigmoid'))
        model.compile(optimizer='adam', loss='binary_crossentropy')
        return model

    def predict_move(self, history_self, history_opponent):
        input_data = self.encode_histories(history_self, history_opponent)
        prediction = self.model.predict(np.array([input_data]), verbose=0)[0][0]
        return "D" if prediction > 0.5 else "C"

    def encode_histories(self, h1, h2):
        h1_enc = [1 if x == "D" else 0 for x in h1[-2:]]
        h2_enc = [1 if x == "D" else 0 for x in h2[-2:]]
        return (h1_enc + [0, 0])[:2] + (h2_enc + [0, 0])[:2]
def always_cooperate(history_self, history_opponent):
    return "C"

def always_defect(history_self, history_opponent):
    return "D"

def tit_for_tat(history_self, history_opponent):
    if not history_opponent:
        return "C"
    return history_opponent[-1]

def random_strategy(history_self, history_opponent):
    import random
    return random.choice(["C", "D"])

strategy_pool = {
    "Cooperate": always_cooperate,
    "Defect": always_defect,
    "TFT": tit_for_tat,
    "Random": random_strategy
}
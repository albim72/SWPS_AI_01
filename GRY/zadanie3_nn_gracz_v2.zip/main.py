from population import initialize_population, evaluate_population, evolve_population
import csv, os

GENERATIONS = 10
POP_SIZE = 20
ROUNDS = 20
CSV_FILE = "logs/fitness_history.csv"

def write_header_if_needed(file, population):
    if not os.path.exists(file):
        os.makedirs(os.path.dirname(file), exist_ok=True)
        with open(file, "w", newline="") as f:
            writer = csv.writer(f)
            header = ["Generation"] + [f"Agent{i+1}" for i in range(len(population))]
            writer.writerow(header)

def log_fitness_to_csv(file, generation, population):
    with open(file, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([generation] + [ind.fitness for ind in population])

if __name__ == "__main__":
    population = initialize_population(POP_SIZE)
    write_header_if_needed(CSV_FILE, population)

    for generation in range(1, GENERATIONS + 1):
        print(f"=== Generacja {generation} ===")
        evaluate_population(population, ROUNDS)
        log_fitness_to_csv(CSV_FILE, generation, population)
        population = evolve_population(population)
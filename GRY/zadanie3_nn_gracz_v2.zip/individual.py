class Individual:
    def __init__(self, name, strategy_func, is_nn=False, nn_model=None):
        self.name = name
        self.strategy_func = strategy_func
        self.history = []
        self.fitness = 0
        self.is_nn = is_nn
        self.nn_model = nn_model

    def play(self, opponent, rounds=20):
        self.history = []
        opponent.history = []
        for _ in range(rounds):
            move_self = self.strategy_func(self.history, opponent.history)
            move_op = opponent.strategy_func(opponent.history, self.history)
            self.history.append(move_self)
            opponent.history.append(move_op)
            self.fitness += self.score(move_self, move_op)
            opponent.fitness += self.score(move_op, move_self)

    def score(self, move1, move2):
        if move1 == "C" and move2 == "C": return 3
        if move1 == "C" and move2 == "D": return 0
        if move1 == "D" and move2 == "C": return 5
        if move1 == "D" and move2 == "D": return 1
import os
import csv

def ensure_logs_dir():
    os.makedirs("logs", exist_ok=True)

def save_fitness_to_csv(filepath, generation, population):
    ensure_logs_dir()
    file_exists = os.path.isfile(filepath)
    with open(filepath, "a", newline="") as f:
        writer = csv.writer(f)
        if not file_exists:
            header = ["Generation"] + [f"Agent{i+1}" for i in range(len(population))]
            writer.writerow(header)
        writer.writerow([generation] + [ind.fitness for ind in population])
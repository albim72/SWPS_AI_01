from individual import Individual
from strategies import strategy_pool
from neural_strategy import NeuralStrategy
import random

def initialize_population(size):
    population = []
    for _ in range(size - 1):
        name, func = random.choice(list(strategy_pool.items()))
        population.append(Individual(name, func))
    # Dodajemy jednego gracza z siecią neuronową
    nn_strategy = NeuralStrategy()
    population.append(Individual("Neural", nn_strategy.predict_move, is_nn=True, nn_model=nn_strategy))
    return population

def evaluate_population(population, rounds=20):
    for ind in population:
        ind.fitness = 0
    for i in range(len(population)):
        for j in range(i + 1, len(population)):
            population[i].play(population[j], rounds)

def evolve_population(population):
    population.sort(key=lambda x: x.fitness, reverse=True)
    survivors = population[:len(population) // 2]
    new_population = []

    for agent in survivors:
        if agent.is_nn:
            child_nn = NeuralStrategy()
            child_nn.model.set_weights(agent.nn_model.model.get_weights())
            new_population.append(Individual("Neural", child_nn.predict_move, is_nn=True, nn_model=child_nn))
        else:
            new_population.append(Individual(agent.name, agent.strategy_func))

    while len(new_population) < len(population):
        name, func = random.choice(list(strategy_pool.items()))
        new_population.append(Individual(name, func))

    return new_population
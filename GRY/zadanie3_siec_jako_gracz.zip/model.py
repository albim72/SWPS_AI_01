from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
import numpy as np

def build_model():
    model = Sequential()
    model.add(Dense(10, input_dim=5, activation='relu'))
    model.add(Dense(1, activation='sigmoid'))
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    return model

def encode_history(history):
    return [1 if move == 'D' else 0 for move in history]
from model import build_model, encode_history
import numpy as np

# Przykładowe dane treningowe
X = []
y = []

# Generowanie danych: jeśli przeciwnik ostatnio zdradzał, uczymy 'D', w przeciwnym wypadku 'C'
for i in range(1000):
    hist = np.random.choice(['C', 'D'], size=5)
    encoded = encode_history(hist)
    X.append(encoded)
    if list(hist).count('D') > 2:
        y.append(1)  # Zdradź
    else:
        y.append(0)  # Współpracuj

X = np.array(X)
y = np.array(y)

# Budujemy i trenujemy model
model = build_model()
model.fit(X, y, epochs=10, verbose=1)

# Przykład predykcji
test_hist = ['C', 'D', 'D', 'C', 'D']
x_test = np.array([encode_history(test_hist)])
pred = model.predict(x_test)[0][0]
print(f"Przewidywany ruch: {'D' if pred > 0.5 else 'C'} (wartość: {pred:.2f})")
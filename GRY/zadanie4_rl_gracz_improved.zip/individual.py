
class Individual:
    def __init__(self, name, strategy_func, is_rl=False):
        self.name = name
        self.strategy_func = strategy_func
        self.fitness = 0
        self.history = []
        self.is_rl = is_rl

    def play(self, opponent, rounds=10):
        self.history.clear()
        opponent.history.clear()
        for _ in range(rounds):
            move_self = self.strategy_func.choose_action((self.history[-1] if self.history else "C", 
                                                          opponent.history[-1] if opponent.history else "C"))                         if self.is_rl else self.strategy_func(self.history, opponent.history)
            move_opp = opponent.strategy_func.choose_action((opponent.history[-1] if opponent.history else "C", 
                                                             self.history[-1] if self.history else "C"))                         if opponent.is_rl else opponent.strategy_func(opponent.history, self.history)
            self.history.append(move_self)
            opponent.history.append(move_opp)
            reward_self, reward_opp = self.payoff(move_self, move_opp)
            self.fitness += reward_self
            opponent.fitness += reward_opp
        if self.is_rl:
            self.strategy_func.learn_from(self.history, opponent.history, self.fitness)
        if opponent.is_rl:
            opponent.strategy_func.learn_from(opponent.history, self.history, opponent.fitness)

    def payoff(self, a1, a2):
        if a1 == "C" and a2 == "C":
            return (3, 3)
        elif a1 == "C" and a2 == "D":
            return (0, 5)
        elif a1 == "D" and a2 == "C":
            return (5, 0)
        else:
            return (1, 1)

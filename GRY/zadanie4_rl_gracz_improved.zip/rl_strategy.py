
import random
from collections import defaultdict

class RLPlayer:
    def __init__(self, alpha=0.1, gamma=0.95, epsilon=0.3, epsilon_min=0.05, epsilon_decay=0.93):
        self.alpha = alpha
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_min = epsilon_min
        self.epsilon_decay = epsilon_decay
        self.q_table = defaultdict(lambda: {"C": 0.0, "D": 0.0})
        self.generation = 0

    def choose_action(self, state):
        if random.random() < self.epsilon:
            return random.choice(["C", "D"])
        return max(self.q_table[state], key=self.q_table[state].get)

    def update_q_value(self, state, action, reward, next_state):
        old_value = self.q_table[state][action]
        future_rewards = max(self.q_table[next_state].values())
        new_value = (1 - self.alpha) * old_value + self.alpha * (reward + self.gamma * future_rewards)
        self.q_table[state][action] = new_value

    def learn_from(self, history_self, history_opponent, reward):
        for i in range(len(history_self) - 1):
            state = (history_self[i], history_opponent[i])
            action = history_self[i+1]
            next_state = (history_self[i+1], history_opponent[i+1])
            self.update_q_value(state, action, reward, next_state)

    def update_epsilon(self):
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay
        self.generation += 1


from individual import Individual
from strategies import tit_for_tat, always_cooperate, always_defect, random_strategy
from rl_strategy import RLPlayer

def initialize_population(size=10):
    population = [Individual("RL_Player", RLPlayer(), is_rl=True)]
    for _ in range((size - 1) // 4):
        population.append(Individual("TFT", tit_for_tat))
        population.append(Individual("Coop", always_cooperate))
        population.append(Individual("Defect", always_defect))
        population.append(Individual("Rand", random_strategy))
    return population

def evaluate_population(population, rounds=10):
    for p in population:
        p.fitness = 0
    for i in range(len(population)):
        for j in range(i+1, len(population)):
            population[i].play(population[j], rounds)

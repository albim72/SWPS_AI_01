
import random

def tit_for_tat(history_self, history_opponent):
    if not history_opponent:
        return "C"
    return history_opponent[-1]

def always_cooperate(_, __):
    return "C"

def always_defect(_, __):
    return "D"

def random_strategy(_, __):
    return random.choice(["C", "D"])

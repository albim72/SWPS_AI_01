
from population import initialize_population, evaluate_population
import csv, os

GENERATIONS = 15
POP_SIZE = 17
CSV_FILE = "logs/fitness_history.csv"

def write_header(file, population):
    if not os.path.exists(file):
        with open(file, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Generation"] + [ind.name for ind in population])

def log_fitness(file, generation, population):
    with open(file, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([generation] + [ind.fitness for ind in population])

if __name__ == "__main__":
    population = initialize_population(POP_SIZE)
    write_header(CSV_FILE, population)
    for gen in range(1, GENERATIONS + 1):
        evaluate_population(population, rounds=15)
        log_fitness(CSV_FILE, gen, population)
        for ind in population:
            if ind.is_rl:
                ind.strategy_func.update_epsilon()

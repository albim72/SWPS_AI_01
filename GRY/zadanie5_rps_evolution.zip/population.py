from agent import Agent
from strategies import always_rock, always_paper, always_scissors, random_strategy, rotate
from tournament import run_round
import random

class Population:
    def __init__(self, size=20):
        self.agents = []
        self.size = size
        self.strategy_pool = [
            ("Rock", always_rock),
            ("Paper", always_paper),
            ("Scissors", always_scissors),
            ("Random", random_strategy),
            ("Rotate", rotate),
        ]
        self.init_population()

    def init_population(self):
        for _ in range(self.size):
            name, strat = random.choice(self.strategy_pool)
            self.agents.append(Agent(name, strat))

    def run_tournament(self):
        for agent in self.agents:
            agent.reset()
        for i in range(len(self.agents)):
            for j in range(i + 1, len(self.agents)):
                run_round(self.agents[i], self.agents[j])

    def evolve(self):
        self.agents.sort(key=lambda a: a.score, reverse=True)
        survivors = self.agents[:len(self.agents)//2]
        new_generation = []
        for agent in survivors:
            for _ in range(2):
                name, strat = agent.name, agent.strategy_func
                new_generation.append(Agent(name, strat))
        self.agents = new_generation[:self.size]

    def print_summary(self):
        summary = {}
        for agent in self.agents:
            summary[agent.name] = summary.get(agent.name, 0) + 1
        print("Populacja:", summary)
def get_score(move1, move2):
    if move1 == move2:
        return 0, 0
    rules = {"R": "S", "P": "R", "S": "P"}
    if rules[move1] == move2:
        return 1, 0
    else:
        return 0, 1

def run_round(agent1, agent2, rounds=5):
    for _ in range(rounds):
        m1 = agent1.play()
        m2 = agent2.play()
        s1, s2 = get_score(m1, m2)
        agent1.score += s1
        agent2.score += s2
        agent1.history.append(m1)
        agent2.history.append(m2)
        agent1.opponent_history.append(m2)
        agent2.opponent_history.append(m1)
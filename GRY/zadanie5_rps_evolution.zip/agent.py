class Agent:
    def __init__(self, name, strategy_func):
        self.name = name
        self.strategy_func = strategy_func
        self.history = []
        self.opponent_history = []
        self.score = 0

    def play(self):
        return self.strategy_func(self.history, self.opponent_history)

    def reset(self):
        self.history.clear()
        self.opponent_history.clear()
        self.score = 0
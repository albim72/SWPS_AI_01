from population import Population

if __name__ == "__main__":
    population = Population(size=50)
    generations = 20

    for gen in range(generations):
        print(f"Generacja {gen+1}")
        population.run_tournament()
        population.evolve()
        population.print_summary()
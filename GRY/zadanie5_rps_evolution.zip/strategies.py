import random

def always_rock(_, __):
    return "R"

def always_paper(_, __):
    return "P"

def always_scissors(_, __):
    return "S"

def random_strategy(_, __):
    return random.choice(["R", "P", "S"])

def rotate(history_self, _):
    if not history_self:
        return "R"
    last = history_self[-1]
    return {"R": "P", "P": "S", "S": "R"}[last]
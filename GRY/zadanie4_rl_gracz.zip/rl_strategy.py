import random
import json
from collections import defaultdict

class RLPlayer:
    def __init__(self, alpha=0.1, gamma=0.9, epsilon=0.1):
        self.q_table = defaultdict(lambda: {"C": 0.0, "D": 0.0})
        self.alpha = alpha
        self.gamma = gamma
        self.epsilon = epsilon

    def choose_action(self, hist_self, hist_opp):
        state = self._encode_state(hist_self, hist_opp)
        if random.random() < self.epsilon:
            return random.choice(["C", "D"])
        return max(self.q_table[state], key=self.q_table[state].get)

    def learn_from(self, hist_self, hist_opp, reward):
        if len(hist_self) == 0:
            return
        state = self._encode_state(hist_self[:-1], hist_opp[:-1])
        action = hist_self[-1]
        next_state = self._encode_state(hist_self, hist_opp)
        max_next = max(self.q_table[next_state].values())
        self.q_table[state][action] += self.alpha * (reward + self.gamma * max_next - self.q_table[state][action])

    def _encode_state(self, h1, h2):
        if len(h1) == 0: return "START"
        return h1[-1] + h2[-1]

def save_q_values(q_table, path):
    with open(path, "w") as f:
        json.dump(q_table, f)
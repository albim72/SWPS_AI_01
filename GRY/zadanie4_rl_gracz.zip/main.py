from population import initialize_population, evaluate_population
from rl_strategy import save_q_values
import csv, os

GENERATIONS = 10
POP_SIZE = 10
ROUNDS = 10
CSV_FILE = "logs/fitness_history.csv"

def write_header_if_needed(file, population):
    if not os.path.exists(file):
        with open(file, "w", newline="") as f:
            writer = csv.writer(f)
            header = ["Generation"] + [f"Agent{i+1}" for i in range(len(population))]
            writer.writerow(header)

def log_fitness_to_csv(file, generation, population):
    with open(file, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([generation] + [ind.fitness for ind in population])

if __name__ == "__main__":
    population = initialize_population(POP_SIZE)
    write_header_if_needed(CSV_FILE, population)

    for generation in range(1, GENERATIONS + 1):
        print(f"\n=== Generacja {generation} ===")
        evaluate_population(population, ROUNDS)
        log_fitness_to_csv(CSV_FILE, generation, population)

    for ind in population:
        if hasattr(ind.strategy_func, "q_table"):
            save_q_values(ind.strategy_func.q_table, "logs/q_values.json")
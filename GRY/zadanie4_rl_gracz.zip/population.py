from individual import Individual
from strategies import strategy_pool
from rl_strategy import RLPlayer
import random

def initialize_population(size):
    population = []
    for i in range(size - 1):
        name, strategy = random.choice(list(strategy_pool.items()))
        population.append(Individual(name, strategy))
    # Dodajemy jednego gracza RL
    population.append(Individual("RLPlayer", RLPlayer(), is_rl=True))
    return population

def evaluate_population(population, rounds):
    for ind in population:
        ind.fitness = 0

    for i in range(len(population)):
        for j in range(i + 1, len(population)):
            population[i].play(population[j], rounds)
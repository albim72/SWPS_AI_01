def always_cooperate(_, __): return "C"
def always_defect(_, __): return "D"

strategy_pool = {
    "Cooperate": always_cooperate,
    "Defect": always_defect
}
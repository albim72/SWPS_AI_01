class Individual:
    def __init__(self, name, strategy_func, is_rl=False):
        self.name = name
        self.strategy_func = strategy_func
        self.fitness = 0
        self.is_rl = is_rl

    def play(self, opponent, rounds):
        history_self, history_opponent = [], []

        for _ in range(rounds):
            move_self = self._get_move(history_self, history_opponent)
            move_opponent = opponent._get_move(history_opponent, history_self)

            reward_self, reward_opponent = self._get_score(move_self, move_opponent)
            self.fitness += reward_self
            opponent.fitness += reward_opponent

            if self.is_rl:
                self.strategy_func.learn_from(history_self, history_opponent, reward_self)
            if opponent.is_rl:
                opponent.strategy_func.learn_from(history_opponent, history_self, reward_opponent)

            history_self.append(move_self)
            history_opponent.append(move_opponent)

    def _get_move(self, self_hist, opp_hist):
        if self.is_rl:
            return self.strategy_func.choose_action(self_hist, opp_hist)
        return self.strategy_func(self_hist, opp_hist)

    def _get_score(self, a, b):
        if a == "C" and b == "C":
            return 3, 3
        elif a == "C" and b == "D":
            return 0, 5
        elif a == "D" and b == "C":
            return 5, 0
        else:
            return 1, 1